<template>
  <div>
    <AppComponent/>
  </div>
</template>

<script>
import AppComponent from '../components/PropsEmit/AppComponent.vue'

export default {
    name: "PropsEmitView",
    components: {
        AppComponent
    },
    data(){
        return {

        }
    }

}
</script>

<style>

</style>