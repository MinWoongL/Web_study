<template>
  <h2>결정세액 : {{resultCal}} 만원</h2>
</template>

<script>
export default {
  name: 'FinaltaxComponent',
  props: {
    resultTax: Number
  },
  data() {
    return {

    }
  },
  computed: {
    resultCal() {
      if (this.resultTax < 0) {
        return 0
      } else {
        return this.resultTax
      }
    }
  },
  method: {
    // disCount() {
    //   // computed 속성의 데이터는 직접 변경이 불가능
    //   this.resultCal -= 100000
    // }
  }
}
</script>

<style>

</style>