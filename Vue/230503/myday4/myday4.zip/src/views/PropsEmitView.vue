<template>
<div>
    <h1>PropsEmitView</h1>
    <IncomeComponent/>
</div>
</template>

<script>
import IncomeComponent from '../components/propsEmit/IncomeComponent.vue'


export default {
    name: 'PropsEmitView',
    components: {
        IncomeComponent
    },
    data() {
        return {

        }
    },
}
</script>

<style>

</style>