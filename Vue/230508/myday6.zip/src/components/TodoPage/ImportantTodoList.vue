<template>
  <div>
    <h3>중요한 일</h3>

  </div>
</template>

<script>
export default {
    name: "ImportantTodoList",

}
</script>

<style>

</style>